package com.example.customerapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerapplicationApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomerapplicationApplication.class, args);
    }

}
